﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public void ReadData()
        {
            FileStream fs = new FileStream("test.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            sr.BaseStream.Seek(0, SeekOrigin.Begin);

            string str = sr.ReadLine();
            while (str != null)
            {
              //  if (str == "prova") se metto questo stampa solo la riga che contiene prova, altrimenti le stampa tutte. Puoi usare la funzione split per separare ciascuna linea in stringhe separate, una con le date e una col valore
                    Console.WriteLine("{0}", str);
                str = sr.ReadLine();
            }
            sr.Close();
            fs.Close();
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.ReadData();
            Console.Read();
        }
    }
}
