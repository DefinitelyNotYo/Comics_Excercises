﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /*
     * Devi creare un programma che restituisca il valore di una certa quantità di bitcoin in una data specifica. 
     * Questo programma deve utilizzare un database in formato csv che rappresenterà il prezzo del bitcoin nel tempo. 
     * Questo database è fornito con questo esercizio. Il programma prenderà come input un secondo database, che memorizzerà i diversi prezzi/date da valutare.

        Il tuo programma deve rispettare queste regole:

        • Il nome del programma è btc.

        • Il tuo programma deve prendere un file come argomento.

        • Ogni riga in questo file deve utilizzare il seguente formato: "data | valore".

        • Una data valida sarà sempre nel seguente formato: Anno-Mese-Giorno.

        • Un valore valido deve essere un float o un numero intero positivo, compreso tra 0 e 1000.

        Devi utilizzare almeno un contenitore nel tuo codice per validare questo esercizio. Dovresti gestire eventuali errori con un messaggio di errore appropriato.


        Il tuo programma utilizzerà il valore nel tuo file di input.

        Il tuo programma dovrebbe visualizzare sull'output standard il risultato del valore moltiplicato per il tasso di cambio in base 
        alla data indicata nel tuo database. Se la data utilizzata nell'input non esiste nel tuo database, devi utilizzare la data più vicina 
        contenuta nel tuo database. Attenzione a utilizzare la data inferiore e non quella superiore.
     */
    class Program
    {
        public static Dictionary <string, float> ReadData()
        {
            Dictionary<string, float> dizionario = new Dictionary<string, float>();

            FileStream fs = new FileStream("data.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            sr.BaseStream.Seek(0, SeekOrigin.Begin);

            string str = sr.ReadLine();
            str = sr.ReadLine();

            while (str != null)
            {
                //  if (str == "prova") se metto questo stampa solo la riga che contiene prova, altrimenti le stampa tutte. Puoi usare la funzione split per separare ciascuna linea in stringhe separate, una con le date e una col valore

                string[] prova = str.Split(',');

                float test = Convert.ToSingle(prova[1]);

                dizionario[prova[0]] = test;
                str = sr.ReadLine();
            }
            sr.Close();
            fs.Close();
            return dizionario;
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            Dictionary<string, float> datadictionary = ReadData();

            FileStream fs = new FileStream("test.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            sr.BaseStream.Seek(0, SeekOrigin.Begin);

            string str = sr.ReadLine();

            string specialKey = null;

            while (str != null)
            {
                try
                {
                    string[] prova = str.Split('|');
                    float moneta;
                    if (prova.Length == 1)
                    {
                        Console.WriteLine("Formato stringa invalido: mancanza dati");
                        throw new Exception("\nFormato stringa invalido: mancanza dati\n");
                    }
                    bool condition = float.TryParse(prova[1], out moneta);
                    if (condition == false)
                    {
                        Console.WriteLine("Formato stringa invalido: formattazione moneta non valido");
                        throw new Exception("\nFormato stringa invalido: formattazione moneta non valido\n");
                    }
                    if (moneta <= 0 && moneta >= 1000)
                    {
                        Console.WriteLine("Formato stringa invalido: valore non in range");
                        throw new Exception("\nFormato stringa invalido: valore non in range\n");
                    }
                    if (validateDate(prova[0]) && condition)
                    {
                        int time = checkTime(prova[0]);
                        foreach(var i in datadictionary)
                        {
                            Console.WriteLine("sono entrato nel foreach");
                            if (checkTime(i.Key) == time)
                            {
                                Console.WriteLine(moneta * i.Value);
                                return;
                            }
                            if (checkTime(i.Key) > time)
                            {
                                if (checkTime(i.Key) - time > Math.Abs(checkTime(i.Key) - checkTime(specialKey))) 
                                {
                                    Console.WriteLine(moneta * datadictionary[specialKey]);
                                }
                                else
                                    Console.WriteLine(moneta * i.Value);
                            }
                            specialKey = i.Key;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Formato stringa invalido: '|' assente");
                        throw new Exception("\nFormato stringa invalido: '|' assente\n");
                    }
                }
                catch(Exception e)
                {
                    System.Diagnostics.Trace.WriteLine("prova");
                }
                str = sr.ReadLine();
            }
            sr.Close();
            fs.Close();
            Console.Read();
        }
        public static bool validateDate(string t)
        {
            string[] prova = t.Split('-');
            if (Convert.ToInt16(prova[0]) > 0 && Convert.ToInt16(prova[1]) > 0 && Convert.ToInt16(prova[1]) < 13 && Convert.ToInt16(prova[2]) > 0 && Convert.ToInt16(prova[2]) < 31)
                return true;
            else
            {
                Console.WriteLine("Formato stringa invalido: formato incorretto o data non valida");
                throw new Exception("\nFormato stringa invalido: formato incorretto o data non valida\n");
            }
        }
        public static int checkTime(string date)
        {
            date.Remove(4, 1);
            date.Remove(5, 1);
            return Convert.ToInt32(date);
        }
    }
}
